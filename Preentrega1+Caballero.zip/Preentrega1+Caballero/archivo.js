//Promedio de Trimestres 
let continuar

do{
    alert("Bienvenido/a al programa para calcular el promedio de trimestres.\nDeberá ingresar sus datos personales, luego las notas correspondientes.")

    let nombre = prompt("Ingresar NOMBRE:")
    nombre = nombre.toLowerCase()

    let apellido = prompt("Ingresar APELLIDO")
    apellido = apellido.toUpperCase()

    function pedirNota(mensaje) {
        let nota;
        do {
            nota = Number(prompt(mensaje + " (debe ser mayor a 0 y menor a 11):"))
        } while (isNaN(nota) || nota <= 0 || nota >= 11)
        return nota
    }

    let n1 = pedirNota("Ingrese la PRIMER nota")
    let n2 = pedirNota("Ingrese la SEGUNDA nota")
    let n3 = pedirNota("Ingrese la TERCER nota")

    promedio = (n1 + n2 + n3) / 3
    promedio = promedio.toFixed(1)
    alert(apellido + ", " + nombre + "\ntu promedio es de " + promedio)
    continuar = prompt("¿Calcular nuevo promedio?\nIngrese 'Y' para confirmar")
} while (continuar == "y")